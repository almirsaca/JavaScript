/*
use this file to write your solution and then share the solution with me.
Exercises are available in the text files at the end of each section.
Instructions are at the top of the text file and 
in the videos JavaScript coding exercises 1 and 2 in the section Introduction
*/